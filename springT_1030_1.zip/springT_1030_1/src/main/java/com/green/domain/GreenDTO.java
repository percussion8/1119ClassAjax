package com.green.domain;

public class GreenDTO {

}
