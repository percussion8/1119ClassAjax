package com.green.domain;

import lombok.Data;

@Data
public class SampleVO {
	int id;
	String name;
	int korea;
	int math;
	int eng;
	int total;
	float avg;

}
