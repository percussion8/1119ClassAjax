package com.green.service;

import java.util.List;

import com.green.domain.Criteria;
import com.green.domain.ReplyVO;

public interface ReplyService {
	public int register(ReplyVO vo);
	public ReplyVO getR(Long rno);
	public int modify(ReplyVO vo);
	public List<ReplyVO> getList(Criteria crit, Long bno);
	public int remove(Long rno);

}
